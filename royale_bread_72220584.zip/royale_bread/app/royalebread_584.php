<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class royalebread_584 extends Model
{
    protected $table = 'roti';

    protected $fillable = ['nama_roti', 'rasa', 'harga', 'stok'];
}
